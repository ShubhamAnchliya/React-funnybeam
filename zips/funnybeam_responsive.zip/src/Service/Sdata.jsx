import imgDigi from "../assets/seo.png"


const Sdata = [
    {
        title: "App Development",
        imgSrc: imgDigi,
        siteD:"https://www.interaction-design.org/literature/topics/web-design"
    },
    {
        title: "SEO",
        imgSrc: imgDigi,
        siteD:"https://www.interaction-design.org/literature/topics/web-design"
    },
    {
        title: "Web Development",
        imgSrc: imgDigi,
        siteD:"https://www.interaction-design.org/literature/topics/web-design"
    },
    {
        title: "Digital Marketing",
        imgSrc: imgDigi,
        siteD:"https://www.interaction-design.org/literature/topics/web-design"
    }
    
];

export default Sdata;