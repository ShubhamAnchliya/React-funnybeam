import React from 'react';
import Navbar from '../../Navbar/Navbar';
import "./AddUser.css";

const AddUser = () => {
  return (
    <>
        <Navbar/>

        <div>

            <h3 className='text-center mt-4'>Add User</h3>

            
            
        </div>
    </>
  )
}

export default AddUser;