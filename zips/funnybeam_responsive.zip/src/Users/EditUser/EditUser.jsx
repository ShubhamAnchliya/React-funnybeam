import React from 'react';
import Navbar from '../../Navbar/Navbar';
import "./EditUser.css";

const EditUser = () => {
  return (
    <>
        <Navbar/>

        <div>
            <h3 className='text-center mt-4'>Edit User</h3>
        </div>
    </>
  )
}

export default EditUser;