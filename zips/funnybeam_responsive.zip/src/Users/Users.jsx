import React from 'react'
import { Link } from 'react-router-dom';
import Navbar from '../Navbar/Navbar';
import "./Users.css";

const Users = () => {
  return (
    <>
        <Navbar/>

        <div  className='main_div'>

        <h3 className='mt-4 heading'>Users List</h3>

            {/* <Link to="/addUser" className="btn btn-sm btn-success mb-2">Add User</Link> */}

            <div className="edit-btns mb-2">

              <Link
               
               to={'/addUser'}
                className="btn btn-primary btn-sm"
                type="button"
              >
                Add Student
              </Link>

              <Link
              
              to={'/'}
                className="btn btn-danger btn-sm m-1" 
               
                type="button"
              >
                Delete List
              </Link>
            </div>

            <table className="table table-bordered table-light">

              <thead>

                <tr>
                  <th >S.No</th>
                  <th >First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Contact No.</th>
                  <th>Action</th>
                </tr>

              </thead>

              <tbody>

                <tr>
                  <th >1</th>
                  <td>Mark</td>
                  <td>Otto</td>
                  <td>@mdo</td>
                  <td>Otto</td>
                  <td className='action_btn'>
                  <Link className="btn btn-success btn-sm "
                  to={""} 
                  // to={`/users/${user.id}`}
                  >
                    View
                  </Link>
                  <Link
                    className="btn btn-primary btn-sm "
                   
                    to={'/editUser'}
                  >
                    Edit
                  </Link>
                  <Link
                    className="btn btn-danger btn-sm "
                    to=""
                    // onClick={() => deleteUser(user.id)}
                  >
                    Delete
                  </Link>
                </td>
                </tr>



              </tbody>

            </table>
                        

            

        </div>


    </>
  )
}

export default Users;